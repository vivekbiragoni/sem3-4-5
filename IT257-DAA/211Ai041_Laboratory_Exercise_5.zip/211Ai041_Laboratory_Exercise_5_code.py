import math

def quality_fn(word):
    if word in word_freq:
        return math.log(word_freq[word])
    else:
        return float('-inf')

def word_segmentation(s, quality_fn):
    n = len(s)
    dp = [float('-inf')] * (n + 1)
    dp[0] = 0
    segs = [None] * (n + 1)
    segs[0] = []

    for i in range(1, n+1):
        for j in range(i):
            word = s[j:i]
            quality = quality_fn(word)
            if quality != float('-inf') and dp[j] + quality > dp[i]:
                dp[i] = dp[j] + quality
                segs[i] = segs[j] + [word]

    return segs[n]

word_freq = {}
n = int(input("Enter the number of words in the frequency dictionary: "))
print("Enter the words and their frequencies (separated by a space):")
for i in range(n):
    word, freq = input().split()
    word_freq[word] = int(freq)

string = input("Enter the string to be segmented: ")
segmentation = word_segmentation(string, quality_fn)

print("\nInput string:", string)
print("Segmentation: " + " ".join(segmentation))

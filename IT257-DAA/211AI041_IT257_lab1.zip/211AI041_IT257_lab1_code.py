class Node:
    def __init__(self, val):
        self.val = val
        self.color = "RED"
        self.left = None
        self.right = None
        self.parent = None

class RedBlackTree:
    def __init__(self):
        self.root = None

    def insert(self, val):
        node = Node(val)
        if self.root is None:
            node.color = "BLACK"
            self.root = node
            return

        curr = self.root
        while curr is not None:
            if val < curr.val:
                if curr.left is None:
                    curr.left = node
                    node.parent = curr
                    break
                curr = curr.left
            else:
                if curr.right is None:
                    curr.right = node
                    node.parent = curr
                    break
                curr = curr.right

        self.fix_violation(node)
        self.print_tree()
    
    def print_tree(self):
        if self.root is None:
            print("Tree is empty")
            return
        self.print_tree_helper(self.root, "", True)

    def print_tree_helper(self, node, indent, last):
        if node is not None:
            print(indent, end="")
            if last:
                print("R----", end="")
                indent += "     "
            else:
                print("L----", end="")
                indent += "|    "

            print(node.val, node.color)

            self.print_tree_helper(node.left, indent, False)
            self.print_tree_helper(node.right, indent, True)

    def fix_violation(self, node):
        while node.parent is not None and node.parent.color == "RED":
            if node.parent == node.parent.parent.left:
                uncle = node.parent.parent.right
                if uncle is not None and uncle.color == "RED":
                    node.parent.color = "BLACK"
                    uncle.color = "BLACK"
                    node.parent.parent.color = "RED"
                    node = node.parent.parent
                else:
                    if node == node.parent.right:
                        node = node.parent
                        self.left_rotate(node)
                    node.parent.color = "BLACK"
                    node.parent.parent.color = "RED"
                    self.right_rotate(node.parent.parent)
            else:
                uncle = node.parent.parent.left
                if uncle is not None and uncle.color == "RED":
                    node.parent.color = "BLACK"
                    uncle.color = "BLACK"
                    node.parent.parent.color = "RED"
                    node = node.parent.parent
                else:
                    if node == node.parent.left:
                        node = node.parent
                        self.right_rotate(node)
                    node.parent.color = "BLACK"
                    node.parent.parent.color = "RED"
                    self.left_rotate(node.parent.parent)

        self.root.color = "BLACK"

    def left_rotate(self, node):
        right_child = node.right
        node.right = right_child.left
        if right_child.left is not None:
            right_child.left.parent = node
        right_child.parent = node.parent
        if node.parent is None:
            self.root = right_child
        elif node == node.parent.left:
            node.parent.left = right_child
        else:
            node.parent.right = right_child
        right_child.left = node
        node.parent = right_child

    def right_rotate(self, node):
        left_child = node.left
        node.left = left_child.right
        if left_child.right is not None:
            left_child.right.parent = node
        left_child.parent = node.parent
        if node.parent is None:
            self.root = left_child
        elif node == node.parent.right:
            node.parent.right = left_child
        else:
            node.parent.left = left_child
        left_child.right = node
        node.parent = left_child


rbt = RedBlackTree()
rbt.insert(27)
rbt.insert(19)
rbt.insert(34)
rbt.insert(7)
rbt.insert(25)
rbt.insert(2)
rbt.insert(31)
rbt.insert(65)
rbt.insert(49)
rbt.insert(98)

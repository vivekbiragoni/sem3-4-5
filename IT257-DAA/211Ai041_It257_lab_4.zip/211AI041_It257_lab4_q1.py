import numpy as np

def matrix_multiply_divide_and_conquer(A, B):
    m, n1 = A.shape
    n2, p = B.shape
    assert n1 == n2, "Matrices have incompatible dimensions."

    if min(m, n1, p) == 1:
        return A @ B  # Use matrix multiplication for 1x1 matrices

    # Pad matrices with zeros to the nearest power of 2
    next_power_of_two = 2**(max(m, n1, p)-1).bit_length()
    A_padded = np.zeros((next_power_of_two, next_power_of_two))
    A_padded[:m, :n1] = A
    B_padded = np.zeros((next_power_of_two, next_power_of_two))
    B_padded[:n2, :p] = B

    # Split matrices into four parts
    mid = next_power_of_two // 2
    A11, A12 = A_padded[:mid, :mid], A_padded[:mid, mid:]
    A21, A22 = A_padded[mid:, :mid], A_padded[mid:, mid:]
    B11, B12 = B_padded[:mid, :mid], B_padded[:mid, mid:]
    B21, B22 = B_padded[mid:, :mid], B_padded[mid:, mid:]

    # Compute intermediate matrices
    P1 = matrix_multiply_divide_and_conquer(A11 + A22, B11 + B22)
    P2 = matrix_multiply_divide_and_conquer(A21 + A22, B11)
    P3 = matrix_multiply_divide_and_conquer(A11, B12 - B22)
    P4 = matrix_multiply_divide_and_conquer(A22, B21 - B11)
    P5 = matrix_multiply_divide_and_conquer(A11 + A12, B22)
    P6 = matrix_multiply_divide_and_conquer(A21 - A11, B11 + B12)
    P7 = matrix_multiply_divide_and_conquer(A12 - A22, B21 + B22)

    


    # Compute output matrices
    C11 = P1 + P4 - P5 + P7
    C12 = P3 + P5
    C21 = P2 + P4
    C22 = P1 - P2 + P3 + P6

    # Combine output matrices
    C = np.vstack((np.hstack((C11, C12)), np.hstack((C21, C22))))
    return C[:m, :p]  # Trim to original size

# Testcase -1
print("Testcase -1")
A = np.array([[1, 2, 3, 4], [5, 6, 7, 8], [9, 10, 11, 12], [13, 14, 15, 16]])
B = np.array([[16, 15, 14, 13], [12, 11, 10, 9], [8, 7, 6, 5], [4, 3, 2, 1]])
C = matrix_multiply_divide_and_conquer(A, B)
print(C)
print("\n\n")

# Test case 0
print("Testcase 0")
A = np.array([[1, 2], [3, 4]])
B = np.array([[5, 6], [7, 8]])
C = matrix_multiply_divide_and_conquer(A, B)
print(C)
print("\n\n")

# Test case 1
print("Testcase 1")
A = np.array([[2, 4], [6, 8]])
B = np.array([[1, 3], [5, 7]])
C = matrix_multiply_divide_and_conquer(A, B)
print(C)
print("\n\n")

# Test case 2
print("Testcase 2")
A = np.array([[2, 4, 6], [8, 10, 12], [14, 16, 18]])
B = np.array([[1, 3, 5], [7, 9, 11], [13, 15, 17]])
C = matrix_multiply_divide_and_conquer(A, B)
print(C)
print("\n\n")

# Test case 3
print("Testcase 3")
A = np.array([[1, 2], [3, 4], [5, 6]])
B = np.array([[7, 8, 9], [10, 11, 12]])
C = matrix_multiply_divide_and_conquer(A, B)
print(C)
print("\n\n")


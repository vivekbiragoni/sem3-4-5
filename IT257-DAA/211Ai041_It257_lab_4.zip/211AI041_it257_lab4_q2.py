# import random
# from functools import reduce

# def generate_shares(k, n, secret):
#     """
#     Generates n shares of a k-th order secret based on Shamir's secret sharing scheme.

#     Args:
#         k (int): The minimum number of shares required to reconstruct the secret.
#         n (int): The total number of shares to generate.
#         secret (int): The secret to be shared.

#     Returns:
#         A list of n tuples, each containing a share index and the corresponding share value.
#     """
#     coefficients = [secret] + [random.randint(0, 256) for _ in range(k-1)] # Generate k-1 random coefficients
#     shares = [(i, evaluate_polynomial(coefficients, i)) for i in range(1, n+1)] # Generate n shares
#     return shares

# def evaluate_polynomial(coefficients, x):
#     """
#     Evaluates a polynomial with the given coefficients at the given value of x.

#     Args:
#         coefficients (list of int): The coefficients of the polynomial, in decreasing order of degree.
#         x (int): The value of x at which to evaluate the polynomial.

#     Returns:
#         The value of the polynomial at x.
#     """
#     return reduce(lambda acc, c: acc*x + c, reversed(coefficients))

# def reconstruct_secret(shares):
#     """
#     Reconstructs the secret from the given shares using Lagrange interpolation.

#     Args:
#         shares (list of tuples): The shares of the secret, each containing a share index and the corresponding share value.

#     Returns:
#         The reconstructed secret.
#     """
#     x_values, y_values = zip(*shares)
#     if len(set(x_values)) != len(x_values):
#         raise ValueError("Duplicate share indices detected")
#     if len(shares) < 2:
#         raise ValueError("At least 2 shares are required")
#     if len(set(y_values)) == 1:
#         return y_values[0] # All shares have the same value, so return it as the secret
#     numerator_coeffs = []
#     denominator_coeffs = []
#     for i in range(len(shares)):
#         xi, yi = shares[i]
#         numerator_coeffs.append(yi)
#         denominator_coeffs.append([1, -xi])
#     numerator_poly = lambda x: evaluate_polynomial(numerator_coeffs, x)
#     denominator_poly = lambda x: reduce(lambda acc, c: acc*evaluate_polynomial(c, x), denominator_coeffs, 1)
#     interpolating_poly = lambda x: numerator_poly(x) / denominator_poly(x)
#     return interpolating_poly(0)

# # Example usage:
# k = 3 # Minimum number of shares required to reconstruct the secret
# n = 5 # Total number of shares to generate
# secret = 12345 # The secret to be shared
# shares = generate_shares(k, n, secret)
# print(shares)

# # Suppose we have k shares and want to reconstruct the secret:
# k_shares = shares[:k]
# reconstructed_secret = reconstruct_secret(k_shares)
# print(reconstructed_secret) # Should print 12345


import random
from functools import reduce

def generate_shares(k, n, secret):
    """
    Generates n shares of a k-th order secret based on Shamir's secret sharing scheme.

    Args:
        k (int): The minimum number of shares required to reconstruct the secret.
        n (int): The total number of shares to generate.
        secret (int): The secret to be shared.

    Returns:
        A list of n tuples, each containing a share index and the corresponding share value.
    """
    coefficients = [secret] + [random.randint(0, 256) for _ in range(k-1)] # Generate k-1 random coefficients
    shares = [(i, evaluate_polynomial(coefficients, i)) for i in range(1, n+1)] # Generate n shares
    return shares

def evaluate_polynomial(coefficients, x):
    """
    Evaluates a polynomial with the given coefficients at the given value of x.

    Args:
        coefficients (list of int): The coefficients of the polynomial, in decreasing order of degree.
        x (int): The value of x at which to evaluate the polynomial.

    Returns:
        The value of the polynomial at x.
    """
    return reduce(lambda acc, c: acc*x + c, reversed(coefficients))

def reconstruct_secret(shares):
    """
    Reconstructs the secret from the given shares using Lagrange interpolation.

    Args:
        shares (list of tuples): The shares of the secret, each containing a share index and the corresponding share value.

    Returns:
        The reconstructed secret.
    """
    x_values, y_values = zip(*shares)
    if len(set(x_values)) != len(x_values):
        raise ValueError("Duplicate share indices detected")
    if len(shares) < 2:
        raise ValueError("At least 2 shares are required")
    if len(set(y_values)) == 1:
        return y_values[0] # All shares have the same value, so return it as the secret
    numerator_coeffs = []
    denominator_coeffs = []
    for i in range(len(shares)):
        xi, yi = shares[i]
        numerator_coeffs.append(yi)
        denominator_coeffs.append([1, -xi])
    numerator_poly = lambda x: evaluate_polynomial(numerator_coeffs, x)
    denominator_poly = lambda x: reduce(lambda acc, c: acc*evaluate_polynomial(c, x), denominator_coeffs, 1)
    interpolating_poly = lambda x: numerator_poly(x) / denominator_poly(x)
    return interpolating_poly(0)

# Interactive mode
while True:
    print("Enter the secret to be shared or 'q' to quit:")
    user_input = input()
    if user_input == 'q':
        break
    try:
        secret = int(user_input)
        print("Enter the minimum number of shares required to reconstruct the secret:")
        k = int(input())
        print("Enter the total number of shares to generate:")
        n = int(input())
        shares = generate_shares(k, n, secret)
        print(f"The {n} shares are:")
        for share in shares:
            print(f"Share {share[0]}: {share[1]}")
        print(f"\nEnter the indices of {k} shares to reconstruct the secret, separated by commas:")
        indices = input().split(',')
        k_shares = [(int(i), shares[int(i)-1][1]) for i in indices]
        reconstructed_secret = reconstruct_secret(k_shares)
        print(f"The reconstructed secret is: {reconstructed_secret}")
    except ValueError:
        print("Invalid input. Please try again.")

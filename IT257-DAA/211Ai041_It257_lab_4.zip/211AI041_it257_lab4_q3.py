import timeit

def square(n):
    if n == 0:
        return 0

    # Split n into three parts of n/3 bits each
    n_third = n.bit_length() // 3
    n1 = n >> (2 * n_third)
    n2 = (n >> n_third) & ((1 << n_third) - 1)
    n3 = n & ((1 << n_third) - 1)

    # Compute the squares of the three parts
    n1_sq = n1 * n1
    n2_sq = n2 * n2
    n3_sq = n3 * n3

    # Compute the cross terms
    n1n2 = n1 * n2
    n1n3 = n1 * n3
    n2n3 = n2 * n3

    # Compute the high and low parts of the result
    high = n1_sq << (2 * n_third)
    high += ((n1n2 + n1n3 + n2n3) << n_third)
    low = n3_sq

    # Add the high and low parts and return the result
    return high + low

# Get input from user
n = int(input("Enter an integer to square: "), 2)
# n = 0b1010101010101010101010101010101010101010101010101010101010101010
# n = 0b1000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000
# n = 0b111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111
# n = 0b101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010

# Time the execution of the square function
t = timeit.timeit(lambda: square(n), number=10000)

# Display the result and running time
result = square(n)
print(f"The square of {n:b} is \n {result:b}")
print(f"Running time: {t:.6f} seconds")

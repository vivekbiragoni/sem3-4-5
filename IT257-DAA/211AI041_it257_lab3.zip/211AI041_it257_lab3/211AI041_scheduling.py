def interval_scheduling(start_times, finish_times):
    # Sort the jobs by finish time
    jobs = sorted(enumerate(zip(start_times, finish_times)), key=lambda x: x[1][1])
    
    # Initialize the result list with the first job
    result = [jobs[0]]
    
    # Iterate through the rest of the jobs and add them to the result list if they don't overlap with the previous job
    for job in jobs[1:]:
        if job[1][0] >= result[-1][1][1]:
            result.append(job)
    
    # Print the chosen jobs along with their indices
    print("Chosen Jobs:")
    for job in result:
        print(f"Job {job[0]+1}: Start Time={job[1][0]}, Finish Time={job[1][1]}")
    
    # Return the number of jobs in the result list
    return len(result)

# # given test case
print(" For the Given test case")
start_times = [1, 0, 1, 0,]
finish_times = [2, 1, 2, 1]
print("********************")

# # trial one
# print("for the example 1")
# start_times = [0, 1, 2, 2, 3, 4, 5]
# finish_times = [6, 3, 4, 5, 5, 6, 7]
# print("********************")

# #trial two 
# print("for the example 2")
# start_times = [1, 0, 1, 0, 3, 4, 5]
# finish_times = [2, 1, 2, 1, 6, 7, 8]
# print("********************")

print("Maximum number of jobs that can be executed:", interval_scheduling(start_times, finish_times))

n = int(input("Enter number of rows: "))
m = int(input("Enter number of columns: ")) 

count = 0
matrix = [["Y" if j % 2 == 0 else "X" for j in range(m)] for i in range(n)]

for j in range(m):
    for i in range(n):
        if j % 2 == 0:
            matrix[i][j] = "Y"
        if matrix[i][j] == "Y":
            count += 1
print("\n\n\n")
print("Here the Y's represent where a student can be seated")
print("Here the X's represent where a student can not be seated")
print()
print("*********************")
for row in matrix:
    print(' '.join(row))
print("*********************")
print("This is the output grid ")
print("*********************")
print("\n\n")
print("Number of students that can be seated in a given room in such a way that they won't be able to copy based on the rules provided in the question:", count)
print("\n\n")
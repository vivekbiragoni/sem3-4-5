def weighted_interval_scheduling(profits, start_times, finish_times):
    jobs = []
    for i in range(len(profits)):
        jobs.append((start_times[i], finish_times[i], profits[i]))

    # Sort jobs by finish time
    jobs.sort(key=lambda x: x[1])

    # Initialize an array to store maximum profit till i-th job
    max_profit = [0] * len(jobs)
    max_profit[0] = jobs[0][2]

    # Initialize an array to store previous non-overlapping job index
    prev_job = [-1] * len(jobs)

    for i in range(1, len(jobs)):
        # Find the latest non-overlapping job
        for j in range(i-1, -1, -1):
            if jobs[j][1] <= jobs[i][0]:
                prev_job[i] = j
                break

        # Calculate maximum profit till i-th job
        with_i = jobs[i][2]
        if prev_job[i] != -1:
            with_i += max_profit[prev_job[i]]

        without_i = max_profit[i-1]

        max_profit[i] = max(with_i, without_i)

    # Find the selected jobs for maximum profit
    selected_jobs = []
    i = len(jobs) - 1
    while i >= 0:
        if jobs[i][2] + (max_profit[prev_job[i]] if prev_job[i] != -1 else 0) > max_profit[i-1]:
            selected_jobs.append(i)
            i = prev_job[i]
        else:
            i -= 1

    # Print the reason for selecting each job
    print("Selected jobs:")
    for i in reversed(selected_jobs):
        reason = "Profit: " + str(jobs[i][2]) + ", "
        if prev_job[i] != -1:
            reason += "Non-overlapping with " + str(prev_job[i]) + ", "
        else:
            reason += "First job, "
        reason += "Finish time: " + str(jobs[i][1])
        print(reason)

    return max_profit[-1]
print("********************")
# given test case
print("For the Given test case")
profits = [100, 10, 15, 27]
start_times = [1, 0, 1, 0]
finish_times = [2, 1, 2, 1]
print("********************")

# # trial one
# print("for the example 1")
# profits = [10, 20, 30, 40, 50, 60, 70, 80, 90, 100]
# start_times = [1, 3, 0, 5, 8, 5, 1, 3, 8, 0]
# finish_times = [4, 5, 6, 7, 9, 9, 2, 4, 10, 3]
# print("********************")

# #trial two 
# print("for the example 2")
# profits = [50, 20, 30, 10, 15, 5, 12, 8]
# start_times = [0, 1, 2, 3, 3, 4, 5, 6]
# finish_times = [3, 3, 4, 5, 6, 5, 7, 8]
# print("********************")

max_profit = weighted_interval_scheduling(profits, start_times, finish_times)
print("Maximum Profit:", max_profit)

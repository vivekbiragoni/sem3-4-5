import requests
from bs4 import BeautifulSoup

# Define the URL of the website
url = "https://www.kannadaprabha.com/"

# Send a request to get the content of the page
response = requests.get(url)
html_content = response.content

# Parse the HTML content
soup = BeautifulSoup(html_content, 'html.parser')

# Find all the <a> tags with class 'article_click' within <h4> tags with class 'subtopic'
article_links = soup.select('h4.subtopic a.article_click')

# Extract the URLs
urls = [link['href'] for link in article_links]

# Print the URLs
for url in urls:
    print(url)

import requests
from bs4 import BeautifulSoup

# List of URLs you want to extract Kannada text from
urls = [
    "https://www.udayavani.com/kannada",
    "https://www.prajavani.net/",
    "https://www.kannadaprabha.com/",
    "https://kannada.asianetnews.com/",
    "https://www.oneindia.com/kannada/",
    "https://publictv.in/kannada-latest-news",
    "https://tv9kannada.com/",
    "https://www.tv5news.in/",
    "https://www.vijaykarnataka.com/",
    "https://www.hosadigantha.com/",
    "https://www.varthabharati.in/",
    "https://www.prajapragathi.com/",
    "https://www.kanaknews.com/",
    "https://www.udayavani.com/kannada",
    "https://www.prabhanews.com/",
    "https://kannada.news18.com/",
    "https://www.vishwavani.news/",
    "https://kannada.webdunia.com/",
    "https://kannada.asianetnews.com/",
    "https://www.udayavani.com/kannada",
    
]


kannada_text = []

for url in urls:
    response = requests.get(url)
    if response.status_code == 200:
        html_content = response.content
        soup = BeautifulSoup(html_content, 'html.parser')
        # kannada_part = soup.find_all('a', class_='article_click')
        # for element in kannada_part:
        #     text = element.text.strip()
        #     kannada_text.append(text)
        # Find all <a> tags that contain links
        article_links = [a['href'] for a in soup.find_all('a') if a.get('href')]

        # Filter out relevant article links
        relevant_links = [link for link in article_links if "article" in link]

        # Print the relevant article links
        for link in relevant_links:
            print(link)


# # Print the extracted Kannada text

# for text in kannada_text:
#     print(text)

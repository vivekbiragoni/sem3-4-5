
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

def scrape_links_and_text(seed_url, text_css_selector):
    
    driver = webdriver.Chrome()

    
    all_links = []

    
    driver.get(seed_url)
    
    links = driver.execute_script("return [...document.querySelectorAll('a')].map(a => a.href);")
    all_links.extend(links)

    
    all_links = list(set(all_links))

    
    with open('extracted_text10.txt', 'a', encoding='utf-8') as file:
        for link in all_links:
            if link.startswith(seed_url):
                driver.get(link)  
                try:
                    wait = WebDriverWait(driver, 10)
                    # element = wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, 'body > main > div.tv9wrapperMain > div.main-col')))
                    # element = wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, 'body > div:nth-child(7) > section.section-content > div.container.SectionContainer > div > div.col-lg-8.col-md-8.col-sm-12.col-xs-12.ColumnSpaceRight > div:nth-child(1) > div')))
                    element = wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, text_css_selector)))
                    text = element.text
                    file.write(text + '\n')  
                except Exception as e:
                    print(f"Error: {e}")

                
                new_links = driver.find_elements(By.CSS_SELECTOR, 'a')
                for new_link in new_links:
                    new_url = new_link.get_attribute('href')
                    
                    if new_url not in all_links:
                        all_links.append(new_url)

    
    driver.quit()


seed_urls = [
    {"url": "https://tv9kannada.com/", "text_selector": 'body > main > div.tv9wrapperMain > div.main-col'},
    {"url": "https://www.kannadaprabha.com/", "text_selector": 'body > div:nth-child(7) > section.section-content > div.container.SectionContainer > div > div.col-lg-8.col-md-8.col-sm-12.col-xs-12.ColumnSpaceRight > div:nth-child(1) > div'},
    {"url": "https://www.prajavani.net/", "text_selector":"#container > div > div > div.PPUXZ > div.story-section"},
    {"url": "https://kannada.asianetnews.com/", "text_selector":"#mainArticleContent > div.PostBody.postbodyneww.tbl-forkorts-article"},
    {"url": "https://publictv.in/kannada-latest-news", "text_selector":"#post-1124124 > div > div.s-ct"},
    {"url": "https://www.vijaykarnataka.com/", "text_selector":"#art-104535614 > div.story-article"},
    {"url": 'https://www.udayavani.com/kannada', "text_selector": '#color-combo-229 > div.left-section > div.white-blk.artical-cnt'},
    {"url": "https://www.varthabharati.in/", "text_selector": '#post-content-wrapper > div > div.single-blog.mb-0'},
    {"url": "https://www.prajapragathi.com/", "text_selector": '#tdi_39'},
    {"url": "https://kannada.news18.com/", "text_selector": 'body > div.nwwrpartcle'},
    {"url": "https://kannada.webdunia.com/", "text_selector": '#root > div > div.mid_content'}
]



for item in seed_urls:
    scrape_links_and_text(item["url"], item["text_selector"])


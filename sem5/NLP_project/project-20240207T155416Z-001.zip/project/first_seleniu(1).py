from selenium import webdriver

# Create a new instance of the Chrome driver
driver = webdriver.Chrome()

# Navigate to the webpage
driver.get("https://www.kannadaprabha.com")

# Execute JavaScript to get all the links
links = driver.execute_script("return [...document.querySelectorAll('a')].map(a => a.href);")

# Close the browser
driver.quit()

# Print the URLs
for url in links:
    print(url)

from selenium import webdriver
driver = webdriver.Chrome()
driver.get("https://www.google.com/search?q=github&oq=&gs_lcrp=EgZjaHJvbWUqCQgBEEUYOxjCAzIJCAAQRRg7GMIDMgkIARBFGDsYwgMyCQgCEEUYOxjCAzIJCAMQRRg7GMIDMgkIBBBFGDsYwgMyCQgFEEUYOxjCAzIJCAYQRRg7GMIDMgkIBxBFGDsYwgPSAQ00NjEwMDgyNDZqMGo3qAIIsAIB&sourceid=chrome&ie=UTF-8")
print(driver.title)
# Zebra-Problem
Project completed for data sturctures.  

The zebra puzzle is a well-known logic puzzle. Many versions of the puzzle exist, including a version published
in Life International magazine on December 17, 1962 (slightly modified here – note that there are 5 houses):
1. The Englishman lives in the red house.
2. The Spaniard owns the dog.
3. Coffee is drunk in the green house.
4. The Ukrainian drinks tea.
5. The green house is immediately to the right of the ivory house.
6. The Snakes and Ladders player owns snails.
7. Cluedo is played in the yellow house.
8. Milk is drunk in the middle house.
9. The Norwegian lives in the first house.
10. The man who plays Pictionary lives in the house next to the man with the fox.
11. Cluedo is played in the house next to the house where the horse is kept.
12. The Travel the World player drinks orange juice.
13. The Japanese plays Backgammon.
14. The Norwegian lives next to the blue house.
Now, who drinks water? Who owns the zebra?
In the interest of clarity, it must be added that each of the five houses is painted a different color, and
their inhabitants are of different national extractions, own different pets, drink different beverages and
play different board games. One other thing: in statement 5, right means your right.”

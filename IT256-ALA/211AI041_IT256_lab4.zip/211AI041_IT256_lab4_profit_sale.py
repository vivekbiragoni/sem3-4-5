# Define the profit and sales vectors
p = [8, 5, 10, -3, 6]
s = [100, 50, 70, 40, 90]

# Calculate the total profit
profit = [p[i]*s[i] for i in range(len(p))]
total_profit = sum(profit)

print("Total profit: $", total_profit)
print()
print()
# Increase the profit by 20%
print("Increase the profit by 20%")
new_p = [1.2 * p[i] for i in range(len(p))]
new_profit = [new_p[i]*s[i] for i in range(len(new_p))]
new_total_profit = sum(new_profit)

print("New total profit: $", new_total_profit)
